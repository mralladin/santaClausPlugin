<?php

get_header();

?>

<script>

function report(){
<?php 
    if (isset($_GET['author'])) {
        $user_id = $_GET['author'];
    }
    $url =  "//{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}";
    ?>
    var user_id=<?php echo $user_id; ?>;
    var url='<?php echo $url; ?>';
    if(confirm("Möchten Sie den Nutzer wirklich melden?")){
        jQuery.ajax({
            type: "POST",
            url: 'wp-content/plugins/nk_plugin/report.php',
            data: {url: url,user_id:user_id},
            success: function(data){
                alert("Danke sehr der Nutzer wurde gemeldet.");
            },
            error: function(XMLHttpRequest, textStatus, errorThrown) { 
                alert("User wurde nicht gemeldet Status: " + textStatus); alert("Error: " + errorThrown); 
            }    
        });  
    }
}

function unlock(){
<?php 
    if (isset($_GET['author'])) {
        $user_id = $_GET['author'];
    }
    
    
    ?>
    var user_id=<?php echo $user_id; ?>;
    <?php
    $current_user = wp_get_current_user();
    ?>
    var guest_id=<?php echo $current_user->ID; ?>;
   
    if(confirm("Möchten Sie Profilfreigabe anfragen?")){
        jQuery.ajax({
    type: "POST",
    url: 'wp-content/plugins/nk_plugin/unlock.php',
    data: {guest_id: guest_id,user_id:user_id},
    success: function(data){
       // console.log(data)
alert("Profilanfrage wurde gesendet.");
    },
    error: function(XMLHttpRequest, textStatus, errorThrown) { 
        alert("User wurde nicht angefragt: " + textStatus); 
    }    
});

    
}

}




function sendmail(){
<?php 
    if (isset($_GET['author'])) {
        $user_id = $_GET['author'];
    }
?>
    var user_id=<?php echo $user_id; ?>;
    var message=document.getElementById('message').innerHTML;
    if(confirm("Nachricht senden?"))
    {
        jQuery.ajax({
    type: "POST",
    url: 'wp-content/plugins/nk_plugin/contact.php',
    data: {message: message,user_id:user_id},
    success: function(data){
        alert("Danke sehr Nachricht wurde gesendet.");
        
    },
    error: function(XMLHttpRequest, textStatus, errorThrown) { 
        alert("Nachricht wurde nicht gesendet. Status: " + textStatus); alert("Error: " + errorThrown); 
    }    
        });
    }
}

</script>

<div class="wrap">
	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">

			<section class="error-404 not-found">
				<header class="page-header">
                    <?php 
                        if (isset($_GET['author'])) {
                            $user_id = $_GET['author'];
                        }
                        $current_user = wp_get_current_user();


                        $user = get_user_by('id',$user_id);

                        $spec_mail = $current_user->user_email;
                        $spec_user_id = $current_user->ID;
                     
                    

                    $val1='ist kein Nikolaus';
                    if(get_the_author_meta( 'nikolaus', $user_id )=='YES')
                    {
                        $val1='ist ein Nikolaus';
                    }

                    
                    
                    
                    ?>
                    <h1 class="page-title"><?php _e( 'User: '. get_userdata( $_GET['author'])->user_login .'  '. $val1); ?></h1>
              



				</header><!-- .page-header -->
				<div class="page-content">
				      
                <?php
                $unlock_array= array();
                if(!(empty(get_the_author_meta( 'unlocks',  $current_user->ID ))))
                $unlock_array=get_the_author_meta( 'unlocks',  $current_user->ID );
               
            

                ?><img src="<?php echo esc_url( get_the_author_meta( 'profile_picture', $user_id ) ); ?>" style="width:150px;"><br /><?php
                ?> 
                <?php 
                
                if(!(in_array($user_id,$unlock_array)||$current_user->ID==$user_id)&&is_user_logged_in())
                echo 
                '<button id="unlockbutton" onclick="unlock()">Profilfreigabe anfragen</button>';
                
                ?>
                <p>Vorname: <?php
                if(in_array($user_id,$unlock_array)||$current_user->ID==$user_id){
                    echo  get_the_author_meta( 'firstname', $user_id )  ;
                }else{
                    echo 'Nur für freigeschaltete Benutzer sichtbar.';
                }
                ?></p><?
                ?> <p>Nachname: <?php
                
                if(in_array($user_id,$unlock_array)||$current_user->ID==$user_id){
                echo  get_the_author_meta( 'lastname', $user_id )  ;
            }else{
                echo 'Nur für freigeschaltete Benutzer sichtbar.';
            }
                
                ?> </p>
                 <p>Stadt: <?php echo  get_the_author_meta( 'zipcode', $user_id )  ;?>,  <?php echo  get_the_author_meta( 'city', $user_id )  ;?> </p>
                 <p>Adresse: <?php 
                if(in_array($user_id,$unlock_array)||$current_user->ID==$user_id){
                
                echo  get_the_author_meta( 'address', $user_id )  ;
            }else{
                echo 'Nur für freigeschaltete Benutzer sichtbar.';
            }
                
                
                ?> </p>
                <p>Land: <?php echo  get_the_author_meta( 'land', $user_id )  ;?> </p>
                <p>Alter: <?php 
                if(in_array($user_id,$unlock_array)||$current_user->ID==$user_id){
                
                echo  get_the_author_meta( 'age', $user_id )  ;
            }else{
                echo 'Nur für freigeschaltete Benutzer sichtbar.';
            }
                
                
                ?> </p>
               
                <p>Zusätliche Informationen: <?php echo  get_the_author_meta( 'bio', $user_id )  ;?> </p>
                <h5>Arbeits Bereiche:</h5>
                <?php 
                if(get_the_author_meta( 'tag1', $user_id )=='YES' ){
                    echo 'Ich möchte Ehrenamtlich arbeiten.</br>';
                }
                if(get_the_author_meta( 'tag2', $user_id )=='YES' ){
                    echo 'Ich möchte in Krankenhäusern arbeiten.</br>';
                }
                if(get_the_author_meta( 'tag3', $user_id )=='YES' ){
                    echo 'Ich möchte auf Familien Festen arbeiten.</br>';
                }
                if(get_the_author_meta( 'tag4', $user_id )=='YES' ){
                    echo 'Ich möchte in Kaufhäusern arbeiten.</br>';
                }
                if(get_the_author_meta( 'tag5', $user_id )=='YES' ){
                    echo 'Ich möchte in Kirchen arbeiten.</br>';
                }
                if(get_the_author_meta( 'tag6', $user_id )=='YES' ){
                    echo 'Ich möchte in Schulen arbeiten.</br>';
                }
                if(get_the_author_meta( 'tag7', $user_id )=='YES' ){
                    echo 'Ich möchte in der Stadt arbeiten.</br>';
                }
                if(get_the_author_meta( 'tag8', $user_id )=='YES' ){
                    echo 'Ich möchte an anderen Orten arbeiten.</br>';
                }
                ?>

                <h5>Offizielles Zertifikat des <a style="font-weight:bold;" href="http://www.nikolausaktion.org/" target="_blank">   Erzbistum Köln<a>:</h5>
                 
                <a href="<?php 
                   if(in_array($user_id,$unlock_array)||$current_user->ID==$user_id){
                echo esc_url( get_the_author_meta( 'zertifikat', $user_id ) ); 
                
            }
            else{
                $current_url = home_url( add_query_arg( array(), $wp->request ) );
                echo esc_url($current_url.'/wp-content/plugins/nk_plugin/assets/registered.jpg'); 
            }
            
                
                ?>" target="_blank">
                <img src="<?php 
                
                    //Dieser Nutzer besitzt kein Zertifikat


                    if(in_array($user_id,$unlock_array)||$current_user->ID==$user_id){
                    
                echo esc_url( get_the_author_meta( 'zertifikat', $user_id ) ); 
                
                }
                else{
                    $current_url = home_url( add_query_arg( array(), $wp->request ) );

                    echo esc_url($current_url.'/wp-content/plugins/nk_plugin/assets/registered.jpg'); 
                }
                
                ?>" style="width:300px;"><br />
              
                </a>

                <?php
                if(is_user_logged_in()){
                    echo '<form >
                    ';}
                else{
                    echo '<form style="display:none;" >
                    ';
                }
                    ?>
                   


                <table class="form-table" style="border:solid; border-collapse: inherit;    border-width: 1px; padding:10px;">
                <th><h4 style="font-size:14px;">Kontakt  mit <?php  echo   get_userdata( $_GET['author'])->user_login;   ?></h4></th>
                <tr>  
                <th> <label>Von:<label></th>
                <td> <input type="text" readonly value="<?php echo $spec_mail; ?>"  class="regular-text"></input>
                </td>
                </tr>
                <tr>
    
                <tr>
                <th> <label>An:<label></th>
                <td> <input type="text" readonly value="<?php echo $user->user_email; ?>"  class="regular-text"></input>
                </td>


                <tr>
                <th> <label>Nachricht:<label></th>
                <td> <textarea cols="50" rows="5" name="message" id="message" class="regular-text" />Sehr geehrter Herr <?php  echo  get_the_author_meta( 'lastname', $user_id );   ?>, &#13;&#10;mein Name ist Herr <?php  echo  get_the_author_meta( 'lastname', $spec_user_id );?> und ich möchte gerne mit Ihnen Kontakt aufnehmen und Sie gegebenenfalls als Nikolaus buchen.&#13;&#10;Mit freundlichen Grüßen&#13;&#10;<?php  echo  get_the_author_meta( 'firstname', $spec_user_id );?> <?php  echo  get_the_author_meta( 'lastname', $spec_user_id );?></textarea>
                </td>
                
    
                <tr>
                <td><input type="button" onclick="sendmail()"  class="button-primary" value="<?php _e( 'E-Mail senden', 'textdomain' ); ?>" id="mail"/></input>                                                                                                           
                </td>
                </tr>
                
                </table>
                </form>

                </div>
			</section>
            <?php
            	
            if(is_user_logged_in()){
                
                echo  '
                
<span>Stimmt was nicht?
<button style="cursor:pointer;color:red;border-radius:29px; font-size:13px;" onclick="report()">Profil melden</button>
</span>
                ' ;
            }
            ?>            
		</main><!-- #main -->
	</div><!-- #primary -->
</div><!-- .wrap -->
<?php get_footer();?>